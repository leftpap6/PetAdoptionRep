//package com; // Test package
//
//import com.adoptionplatform.Main; // Main application class
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest(classes = Main.class)  // Explicitly specify the Main class
//public class PetAdoptApplicationTests {
//
//    @Test
//    void contextLoads() {
//        // This test just checks if the context loads correctly.
//    }
//}
